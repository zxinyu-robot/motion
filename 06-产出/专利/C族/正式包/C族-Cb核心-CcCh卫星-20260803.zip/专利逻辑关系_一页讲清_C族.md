# C 族发明专利 —— 一页讲清逻辑关系

> 策略：**核心独立案 + 卫星案**，按费收稿。  
> **【设计决策】2026-08-03**：围绕机会 **A+B** 立核心案；机会 **C / D** 作卫星。  
> 索引：`03-技术分析/专利拥挤度与技术空白_分层地图增量与端边契约.md`（patent-sensitive）。

---

## 一、结构（核心 + 卫星）

```text
                    ┌─────────────────────────────────────┐
                    │  C-b 核心独立案 ★（机会 A+B）           │
                    │  LayerDelta 信封 + 内容寻址版本 DAG     │
                    │  compose 纯函数多维 layer 组合         │
                    │  从属：coord_anchor / confidence / MERGE │
                    └──────────────┬──────────────────────┘
                                   │ 依附
              ┌────────────────────┼────────────────────┐
              v                    v                    v
     卫星 C-c（机会 C）      卫星 C-h（机会 D）      （后续）
     AccessTicket          多机 OCC               C-d 拼接
     layer/region/         base_version_hash      C-e/f 动作
     version_cap/qos       冲突仲裁
     lazy materialization

上游薄案 C-a：端侧分层库组织（勿主张「多层地图首次」；划界南湖）
弱网细调度 → A4 / 论文；世界内部存查 → A3（与 C-h 划界）
```

**口诀**：C-b 管「增量对象与版本怎么长」；C-c 管「谁能按契约取」；C-h 管「多机抢写怎么裁」。

原 C0 ≈ C-a + C-b；消费契约从原 C-b 宽案拆出为 **C-c**；原 C3/多机 → **C-h**。

---

## 二、交底文件

| 案件 | 角色 | 主文件 |
|------|------|--------|
| **C-b** | 核心 | `交底书/Cb_发明专利_内容寻址LayerDelta封装与版本组合_技术交底书.md` + `附图/Cb-图1`～`图4` |
| **C-c** | 卫星1 | `交底书/Cc_发明专利_AccessTicket消费契约分发_技术交底书.md` + `附图/Cc-图1`～`图2` |
| **C-h** | 卫星2 | `交底书/Ch_发明专利_多机器人地图版本并发管理_技术交底书.md` + `附图/Ch-图1`～`图2` |
| C-a | 上游薄 | `交底书/Ca_发明专利_端侧增量分层空间地图库_技术交底书.md` |

---

## 三、独权速记

| 案件 | 独权方向 |
|------|----------|
| C-b 独权1 | 内容寻址 LayerDelta 信封 + 写入不可变版本 DAG |
| C-b 独权2 | compose(prev, deltas[]) → new_version 纯函数多维组合 |
| C-b 从属 | coord_anchor 对齐；confidence 加权；MERGE change_type |
| C-c 独权 | 令牌编码 layer/region/version_cap/qos 的分发 |
| C-c 从属 | lazy materialization；按消费者投影 |
| C-h 独权 | 基于 base_version_hash 的乐观并发控制 |
| C-h 从属 | 冲突仲裁策略（rebase / MERGE / 策略引擎） |

---

## 四、交所注意

1. C-b 勿把 content-hash **单独**写成唯一区别特征；须绑 LayerDelta + compose。  
2. C-c 须划界购图鉴权令牌。  
3. C-h 勿抢多机几何融合算法独权；双机证据【待补充】。  
4. 申请日前不公开完整 Spec / 字段定稿。

*版本：2026-08-03（核心+卫星重组）*
